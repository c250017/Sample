package com.restapi.exercise.flagpicker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlagPickerApplicationTests {

    @Test
    void contextLoads() {
    }

}
