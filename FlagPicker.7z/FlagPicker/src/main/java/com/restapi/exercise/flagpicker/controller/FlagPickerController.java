package com.restapi.exercise.flagpicker.controller;

import com.restapi.exercise.flagpicker.model.Continent;
import com.restapi.exercise.flagpicker.service.impl.FlagPickerJasonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import java.util.List;


@RestController
@RequestMapping(path = "/getAllData")
public class FlagPickerController
{

    private FlagPickerJasonService flagPickerJasonService;

    @GetMapping(path="/", produces = "application/json")
    public List<Continent> getContintList()
    {
        return flagPickerJasonService.getContintList();
    }



/*    @RequestMapping(method = RequestMethod.GET, value="/continent/getAllData")

    @ResponseBody
    public List<Continent> getAllData() {
        return FlagPickerOperation.getContintList();
    }

    @RequestMapping(method = RequestMethod.GET, value="/continent/getAllCountryData")

    @ResponseBody
    public List<Continent> getAllCountryData() {
        return FlagPickerOperation.getCountryList();
    }

    @RequestMapping(method = RequestMethod.GET, value="/continent/getFlagData")

    @ResponseBody
    public List<Continent> getFlagData() {
        return Country.getFlagData();
    }*/
}




