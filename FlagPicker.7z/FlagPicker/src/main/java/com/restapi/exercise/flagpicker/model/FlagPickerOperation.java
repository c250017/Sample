package com.restapi.exercise.flagpicker.model;

import java.util.List;

public class FlagPickerOperation {
private static List<Continent> continentList;
private static List<Country> countryList;
private static String flagData;

    public static List<Continent> getContintList(Continent cntnt) {
        continentList.add(cntnt);
        return continentList;
    }

    public static List<Country> getCountryList(Country country){
        countryList.add(country);
        return countryList;
    }

    public static String getFlagData(Country country ){
        flagData= country.getFlag();
        return flagData;
    }
}
