package com.restapi.exercise.flagpicker.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Country {
    @JsonProperty("name")
    String name;
    @JsonProperty("flag")
    String flag;

    public Country(String name, String flag) {
        this.name = name;
        this.flag = flag;
    }

    public String getName() {
        return name;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setName(String name) {
        this.name = name;
    }


}
