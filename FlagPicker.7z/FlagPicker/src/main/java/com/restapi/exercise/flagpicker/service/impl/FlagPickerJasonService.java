package com.restapi.exercise.flagpicker.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.restapi.exercise.flagpicker.model.Continent;
import com.restapi.exercise.flagpicker.model.Country;

public class FlagPickerJasonService {

    private static List<Continent> continentList;
    private static List<Country> countryList;
    private static String flagData;

    public static List<Continent> getContintList() {
       // continentList.add(cntnt);
        return continentList;
    }

    public static List<Country> getCountryList(Country country){
        countryList.add(country);
        return countryList;
    }

    public static String getFlagData(Country country ){
        flagData= country.getFlag();
        return flagData;
    }



    public List getAllData(){
        List<Continent> listOfAllContinents= new ArrayList<>();
        Map<String, HashMap<String, String>> listOfAllCountries= new HashMap<>();
        List<Country> countriesList = new ArrayList<>();
        countriesList.add(new Country("Nigeria", "🇳🇬"));
        countriesList.add(new Country("Ethiopia", "ET"));
        countriesList.add(new Country("Egypt", "EG"));
        countriesList.add(new Country("DR Congo", "CD"));
        countriesList.add(new Country("South Africa", "ZA"));

       // listOfAllCountries.put("");


        return listOfAllContinents;
    }
}
