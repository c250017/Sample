package com.restapi.exercise.flagpicker.model;

import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class Continent {
    @JsonProperty("continent")
    private String name;
    @JsonProperty("countries")
    private List<Country> contries;

    public Continent(String name, List<Country> contries) {
        this.name = name;
        this.contries = contries;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Country> getContries() {
        return contries;
    }

    public void setContries(List<Country> contries) {
        this.contries = contries;
    }
}
